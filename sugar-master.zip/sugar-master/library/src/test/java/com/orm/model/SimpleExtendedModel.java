package com.orm.model;

import com.orm.SugarRecord;


public class SimpleExtendedModel extends SugarRecord {
    public SimpleExtendedModel() {}
}
