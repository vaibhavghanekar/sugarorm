package com.orm.model;


public class NoSugarModel {
    public NoSugarModel() {
    }
}