package com.orm.model;

import com.orm.SugarRecord;

/**
 * Created by sibelius on 02/12/15.
 */
public class EmptyModel extends SugarRecord {
    public EmptyModel() { }
}
